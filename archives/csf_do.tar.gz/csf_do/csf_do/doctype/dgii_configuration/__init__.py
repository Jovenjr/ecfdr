# DGII Configuration Doctype package
