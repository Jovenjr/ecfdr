# Copyright (c) 2023, Navari Limited and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestJobApplicant(FrappeTestCase):
	pass
