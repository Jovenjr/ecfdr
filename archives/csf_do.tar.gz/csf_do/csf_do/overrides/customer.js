frappe.ui.form.on("Customer", {
  refresh: function (frm) {
    set_rnc_required(frm);
  },

  customer_group: function (frm) {
    set_rnc_required(frm);
  },
});

function set_rnc_required(frm) {
  if (!frm.doc.customer_group) return;

  frappe.call({
    method: "frappe.client.get_value",
    args: {
      doctype: "Customer Group",
      filters: { name: frm.doc.customer_group },
      fieldname: "custom_is_rnc_mandatory_in",
    },
    callback: function (r) {
      if (r.message && r.message.custom_is_rnc_mandatory_in) {
        let rnc_required_in = r.message.custom_is_rnc_mandatory_in;

        let is_mandatory = ["Customer", "All"].includes(rnc_required_in);

        frm.set_df_property("tax_id", "reqd", is_mandatory);
      }
    },
  });
}
