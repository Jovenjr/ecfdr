# Dominican Republic Sales Tax Report  

**Dominican Republicn Sales Tax Report**, is designed to generate **ITBIS-compliant summaries** with supplier details, taxable amounts, and invoice returns. It includes an automated **CSV export** for easy tax reporting.  

## Features  

- **Filters by Date & Company** – Fetches **approved/submitted** sales invoices within a specified period.  
- **Tax Categorization** – Groups invoices under item tax templates e.g., **ITBIS 16%, Exempt, and Zero-Rated**.  
- **Detailed Tax Breakdown** – Computes **taxable value and ITBIS amounts** per supplier.  
- **Handles Returns** – Links return invoices to their original purchases.  
- **Automated CSV Export** – Generates structured CSV files for **DGII tax submissions**.  

## How to Use  

1.  **Accessing the Report:** Once installed, you can access the report through the ERPNext user interface. Go to "Dominican Republic Workspace" -> "Dominican Republic Purchase Tax Report" or on the "Awesome Searchbar"
2.  **Filtering:**
    *   Company (required)
    *   Date Range (required) i.e., From Date - To Date
    *   Is Return (optional)
    *   Tax Template (optional)

![Dominican Republic Sales Tax Report](../images/dominican_sales_tax_report.png)

3. View the **detailed tax summary** grouped by tax categories.  
4. Click **Export CSVs** to generate a tax-compliant CSV file.

![Export Dominican Republic Sales Tax Report](../images/dominican_sales_tax_report_export.png)
![Generated Files](../images/generated_sales_files.png)

5. Download and Upload the **CSV files**.  

## Configuration  

- Ensure your item tax templates for the general, exempt and zero-rated tax templates contain the words "ITBIS 16%", "Exempt", "Zero Rated". 

## Troubleshooting  

- **Report shows no data?** Ensure sales invoices exist for the selected **company & date range**.  
